from rest_framework.views import APIView
from users.models import Users, Articles
from rest_framework.response import Response
from .serializers import UserSerializer, UserCreateSerializer, ArticleSerializer
from rest_framework import status
import jwt
import time
from django.conf import settings
from django.db.models import Q

from rest_framework.viewsets import ModelViewSet
from rest_framework.routers import DefaultRouter
from django_filters.rest_framework.backends import DjangoFilterBackend
from rest_framework.filters import SearchFilter


# 基于视图的写法
class UsersView(APIView):

    def get(self, request):
        # 查询所有用户
        # users = Users.objects.all()

        # 根据前端传参，进行条件查询
        users = Users.objects.all()
        email = request.GET.get("email")
        first_name = request.GET.get('first_name')
        last_name = request.GET.get('last_name')
        search = request.GET.get('search')

        if email:
            users = users.filter(email=email)
        if first_name:
            users = users.filter(first_name=first_name)
        if last_name:
            users = users.filter(last_name=last_name)

        # Users.objects.filter(
        #     email=email,
        #     first_name=first_name,
        #     last_name=last_name
        # )
        # Users.objects.filter(email=email).filter(first_name=first_name)

        # 搜索用户
        if search:
            users = users.filter(
                Q(email__icontains=search) |
                Q(first_name__icontains=search) |
                Q(last_name__icontains=search)
            )

        # 循环
        # users_data = []
        # for user in users:
        #     users_data.append({
        #         "email": user.email,
        #         "first_name": user.first_name,
        #         "last_name": user.last_name
        #     })

        # 列表生成式
        # users_data = [
        #     {
        #         "email": user.email,
        #         "first_name": user.first_name,
        #         "last_name": user.last_name
        #     } for user in users
        # ]

        # 序列化器
        users_data = UserSerializer(users, many=True).data

        return Response({
            "code": 200,
            "message": 'success',
            "data": {
                "list": users_data
            }
        })

    def post(self, request):
        user_data = request.data

        serializer = UserCreateSerializer(data=user_data)
        if not serializer.is_valid():
            return Response({
                'errors': serializer.errors
            })

        user = Users.objects.create(
            email=user_data['email'],
            first_name=user_data['first_name'],
            last_name=user_data['last_name'],
            password=user_data['password']
        )

        user_result = UserSerializer(user).data
        return Response({
            'code': 200,
            "data": user_result
        })


class UsersDetailView(APIView):

    def get(self, request, user_id):
        # 通过objects.get查询用户
        # try:
        #     user = Users.objects.get(id=user_id)
        # except Users.DoesNotExist:
        #     return Response({}, status=status.HTTP_404_NOT_FOUND)

        # 通过filter查询用户
        user = Users.objects.filter(id=user_id).first()
        if not user:
            return Response({}, status=status.HTTP_404_NOT_FOUND)
        user_result = UserSerializer(user).data
        return Response({
            'code': 200,
            "data": user_result
        })

    def put(self, request, user_id):
        pass

    def delete(self, request, user_id):
        pass


class Login(APIView):
    authentication_classes = ()

    def post(self, request):
        login_data = request.data

        user = Users.objects.filter(
            email=login_data['email'],
            password=login_data['password']
        ).first()

        if not user:
            return Response({}, status=status.HTTP_404_NOT_FOUND)
        payload = {
            'email': user.email,
            'exp': int(time.time()) + 60 * 60
        }
        token = jwt.encode(payload, settings.SECRET_KEY)

        return Response({
            'token': token
        })


# 查询文章列表
# 使用缓存
# from django.utils.decorators import method_decorator
# from django.views.decorators.cache import cache_page
# 
# 
# @method_decorator(decorator=cache_page(timeout=600), name='get')
class ArticleView(APIView):
    def get(self, request):
        from django.core.cache import cache
        artical_data = cache.get('article_data')
        if artical_data:
            return Response({
                'list': artical_data
            })
        articles = Articles.objects.all().prefetch_related('user')

        # 尽量不要在循环中去查询数据
        # id_list = request.GET.getlist("id_list", [])
        # articles = Articles.objects.filter(id__in=id_list).prefetch_related('user')

        # for _id in id_list:
        #     
        #     [].append(Articles.objects.filter(id=_id))
        article_data = ArticleSerializer(articles, many=True).data
        # article_list = []
        # for article in articles:
        #     article_list.append({
        #         'id': article.id,
        #         "user_data": {
        #             "email": article.user.email
        #         }
        #     })

        # 编程式缓存

        cache.set('article_data', article_data, timeout=600)
        return Response({
            "list": article_data
        })


# 基于视图集的写法
class UsersViewSet(ModelViewSet):
    queryset = Users.objects.all()
    serializer_class = UserSerializer
    filter_backends = (DjangoFilterBackend, SearchFilter)
    filterset_fields = ['email', 'first_name', 'last_name']
    search_fields = ['email', 'first_name', 'last_name']


user_router = DefaultRouter()
user_router.register('users', UsersViewSet)
