from django.db import models
from utils.base_model import BaseModel


class Users(BaseModel):
    email = models.CharField(null=False, blank=False, max_length=200)
    first_name = models.CharField(null=False, blank=False, max_length=200)
    last_name = models.CharField(null=False, blank=False, max_length=200)
    password = models.CharField(null=False, blank=False, max_length=200)

    class Meta:
        db_table = 'users'
        verbose_name = 'users'
        verbose_name_plural = 'users'
