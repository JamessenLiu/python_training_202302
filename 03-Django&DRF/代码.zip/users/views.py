from rest_framework.views import APIView
from users.models import Users
from rest_framework.response import Response
from .serializers import UserSerializer, UserCreateSerializer
from rest_framework import status
import jwt
import time
from django.conf import settings

from rest_framework.viewsets import ModelViewSet
from rest_framework.routers import DefaultRouter


# 基于视图的写法
class UsersView(APIView):

    def get(self, request):
        # 查询所有用户
        users = Users.objects.all()

        # 循环
        # users_data = []
        # for user in users:
        #     users_data.append({
        #         "email": user.email,
        #         "first_name": user.first_name,
        #         "last_name": user.last_name
        #     })

        # 列表生成式
        # users_data = [
        #     {
        #         "email": user.email,
        #         "first_name": user.first_name,
        #         "last_name": user.last_name
        #     } for user in users
        # ]

        # 序列化器
        users_data = UserSerializer(users, many=True).data

        return Response({
            "code": 200,
            "message": 'success',
            "data": {
                "list": users_data
            }
        })

    def post(self, request):
        user_data = request.data

        serializer = UserCreateSerializer(data=user_data)
        if not serializer.is_valid():
            return Response({
                'errors': serializer.errors
            })

        user = Users.objects.create(
            email=user_data['email'],
            first_name=user_data['first_name'],
            last_name=user_data['last_name'],
            password=user_data['password']
        )

        user_result = UserSerializer(user).data
        return Response({
            'code': 200,
            "data": user_result
        })


class UsersDetailView(APIView):

    def get(self, request, user_id):
        # 通过objects.get查询用户
        # try:
        #     user = Users.objects.get(id=user_id)
        # except Users.DoesNotExist:
        #     return Response({}, status=status.HTTP_404_NOT_FOUND)

        # 通过filter查询用户
        user = Users.objects.filter(id=user_id).first()
        if not user:
            return Response({}, status=status.HTTP_404_NOT_FOUND)
        user_result = UserSerializer(user).data
        return Response({
            'code': 200,
            "data": user_result
        })

    def put(self, request, user_id):
        pass

    def delete(self, request, user_id):
        pass


class Login(APIView):
    authentication_classes = ()

    def post(self, request):
        login_data = request.data

        user = Users.objects.filter(
            email=login_data['email'],
            password=login_data['password']
        ).first()

        if not user:
            return Response({}, status=status.HTTP_404_NOT_FOUND)
        payload = {
            'email': user.email,
            'exp': int(time.time()) + 60 * 60
        }
        token = jwt.encode(payload, settings.SECRET_KEY)

        return Response({
            'token': token
        })
    

# 基于视图集的写法
class UsersViewSet(ModelViewSet):
    
    queryset = Users.objects.all()
    serializer_class = UserSerializer


user_router = DefaultRouter()
user_router.register('users', UsersViewSet)
