from rest_framework import serializers

from users.models import Users


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        # fields = ['id', 'email']
        exclude = ['password']


class UserCreateSerializer(serializers.Serializer):
    email = serializers.EmailField(
        required=True,
        allow_null=False,
        allow_blank=False,
        max_length=200,
        # error_messages={
        #     'invalid': 'erorr email',
        #     'null': 'email not allow null',
        #     'blank': "xxx",
        #     'max_length': 'XXX'
        # }
    )
    first_name = serializers.CharField(
        required=True,
        allow_null=False,
        allow_blank=False,
        max_length=200
    )

    last_name = serializers.CharField(
        required=True,
        allow_null=False,
        allow_blank=False,
        max_length=200
    )

    password = serializers.CharField(
        required=True,
        allow_null=False,
        allow_blank=False,
        max_length=200
    )
