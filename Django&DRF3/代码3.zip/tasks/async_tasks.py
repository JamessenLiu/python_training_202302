import csv

from tasks.task import app
from users.models import Users


@app.task
def export_users(email):
    users = Users.objects.all().values('email', 'first_name', 'last_name')
    if email:
        users = users.filter(email=email)
    import time
    time.sleep(5)
    with open('users.csv', 'w', encoding='utf-8') as f:
        user_csv = csv.DictWriter(f, fieldnames=['email', 'first_name', 'last_name'])
        user_csv.writeheader()
        for user in users:
            user_csv.writerow(user)
    return
