from django.db import models
from utils.base_model import BaseModel

from users.manager import UserManager


class Users(BaseModel):
    email = models.CharField(null=False, blank=False, max_length=200)
    first_name = models.CharField(null=False, blank=False, max_length=200)
    last_name = models.CharField(null=False, blank=False, max_length=200)
    password = models.CharField(null=False, blank=False, max_length=200)

    objects = UserManager()

    class Meta:
        db_table = 'users'
        verbose_name = 'users'
        verbose_name_plural = 'users'


class Articles(BaseModel):
    title = models.CharField(max_length=200)
    content = models.TextField()
    user = models.ForeignKey(Users, related_name='user_articles', on_delete=models.CASCADE)

    class Meta:
        db_table = 'articles'
