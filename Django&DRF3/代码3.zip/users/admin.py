from django.contrib import admin
from users.models import Users, Articles

admin.site.register(Users)
admin.site.register(Articles)
