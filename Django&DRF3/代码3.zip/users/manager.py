from django.db.models import Manager, Q
from django.db.models.query import QuerySet


class UserQuerySet(QuerySet):
    def get_user_by_email(self, email):
        return self.filter(email=email)

    def get_user_by_first_name(self, first_name):
        return self.filter(first_name=first_name)

    def get_user_by_last_name(self, last_name):
        return self.filter(last_name=last_name)

    def search_users(self, search):
        return self.filter(
            Q(email__icontains=search) |
            Q(first_name__icontains=search) |
            Q(last_name__icontains=search)
        )


class UserManager(Manager):

    def get_all_users(self):
        return self.all()

    def get_queryset(self):
        return UserQuerySet(self.model)
