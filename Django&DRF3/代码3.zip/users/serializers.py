from rest_framework import serializers

from users.models import Users, Articles


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        # fields = ['id', 'email']
        exclude = ['password']


class UserCreateSerializer(serializers.Serializer):
    email = serializers.EmailField(
        required=True,
        allow_null=False,
        allow_blank=False,
        max_length=200,
        # error_messages={
        #     'invalid': 'erorr email',
        #     'null': 'email not allow null',
        #     'blank': "xxx",
        #     'max_length': 'XXX'
        # }
    )
    first_name = serializers.CharField(
        required=True,
        allow_null=False,
        allow_blank=False,
        max_length=200
    )

    last_name = serializers.CharField(
        required=True,
        allow_null=False,
        allow_blank=False,
        max_length=200
    )

    password = serializers.CharField(
        required=True,
        allow_null=False,
        allow_blank=False,
        max_length=200
    )


class ArticleSerializer(serializers.ModelSerializer):
    # email = serializers.CharField(source='user.email')
    # first_name = serializers.CharField(source='user.first_name')
    # last_name = serializers.CharField(source='user.last_name')

    user_data = serializers.SerializerMethodField()

    def get_user_data(self, obj):
        return UserSerializer(obj.user).data

    class Meta:
        model = Articles
        fields = ['id', 'title', 'content', 'user_data']
