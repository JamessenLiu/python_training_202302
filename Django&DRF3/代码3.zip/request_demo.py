import requests
import json

url = 'https://api.bigcommerce.com/stores/rmz2xgu42d/v2/customers'

headers = {
    'x-Auth-Token': 'ol999cchp7xq536507sq3pbjia3fi43',
    'Content-Type': 'application/json',
    'Accept': 'application/json'
}

# 获取用户

# result = requests.get(url, headers=headers)
# customets = result.json()
# print(customets)


# 创建用户
user_data = {
    "_authentication": {},
    "company": "string",
    "email": "test123@test31.com",
    "first_name": "string",
    "last_name": "string",
    "phone": "string",
    "store_credit": 0,
    "registration_ip_address": "string",
    "customer_group_id": 0,
    "notes": "string",
    "tax_exempt_category": "string"
}

result = requests.post(url, headers=headers, data=json.dumps(user_data))
print(result)
